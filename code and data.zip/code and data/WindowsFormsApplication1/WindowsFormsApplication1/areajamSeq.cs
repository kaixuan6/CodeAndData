﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public class areajamSeq
    {
        public List<TCES> areajam = new List<TCES>();
        public List<int> areajam2 = new List<int>();
        public List<string> linkList = new List<string>();
    }
}
