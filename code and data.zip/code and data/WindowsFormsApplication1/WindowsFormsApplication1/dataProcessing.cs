﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics;
using MathNet.Numerics.LinearAlgebra.Double;

namespace WindowsFormsApplication1
{
    //数据处理
    class dataProcessing
    {

        static List<TCES> finaljam = new List<TCES>();
        static List<areajamSeq> areajamEventList = new List<areajamSeq>();
        static List<areajamSeq> areajamEventList2 = new List<areajamSeq>();

        static List<double> SC = new List<double>();
        static List<Group> cesGroup = new List<Group>();


        //Cluster the TCES within each congested area
        public static void areaEventCluster3(double distance1, string path)
        {

            for (int i = 0; i < areajamEventList.Count; i++)
            {
                if (areajamEventList[i].areajam.Count > 100)
                {
                    for (int j = 0; j < areajamEventList[i].areajam.Count; j++)
                    {
                        areajamEventList[i].areajam[j].jamEventareaID = j;
                    }

                    //Build a grouping index for the current area
                    cesGroup = new List<Group>();
                    string linkid = "";

                    for (int j = 0; j < areajamEventList[i].areajam.Count; j++)
                    {
                        linkid = areajamEventList[i].areajam[j].jamE1[0][0].linkID;
                        Boolean lable = false;
                        for (int k = 0; k < cesGroup.Count; k++)
                        {
                            if (cesGroup[k].linkID == linkid)
                            {
                                cesGroup[k].CESid.Add(areajamEventList[i].areajam[j].jamEventareaID);
                                cesGroup[k].CES.Add(areajamEventList[i].areajam[j]);
                                areajamEventList[i].areajam[j].groupID = k;
                                lable = true;
                                break;
                            }
                        }
                        if (lable == false)
                        {
                            Group newgroup = new Group();
                            newgroup.linkID = areajamEventList[i].areajam[j].jamE1[0][0].linkID;
                            newgroup.CESid.Add(areajamEventList[i].areajam[j].jamEventareaID);
                            newgroup.CES.Add(areajamEventList[i].areajam[j]);
                            cesGroup.Add(newgroup);
                            areajamEventList[i].areajam[j].groupID = cesGroup.Count;
                        }
                    }

                    //Build B-tree index for the current group
                    for (int j = 0; j < cesGroup.Count; j++)
                    {
                        balance_Tree.balanceTree bst = new balance_Tree.balanceTree();
                        List<double> h1 = new List<double>();
                        for (int k = 0; k < cesGroup[j].CESid.Count; k++)
                        {
                            double x = areajamEventList[i].areajam[cesGroup[j].CESid[k]].jamLength;
                            h1.Add(x);
                        }
                        cesGroup[j].CESlength = h1;

                        for (int k = 0; k < cesGroup[j].CESid.Count; k++)
                        {
                            bst.Insert(h1.ToArray(), k);
                        }
                        cesGroup[j].pTree = bst;

                        List<string> initallinkIDList = new List<string>();
                        for (int k = 0; k < cesGroup[j].CES.Count; k++)
                        {
                            for (int m = 0; m < cesGroup[j].CES[k].jamE1[0].Count; m++)
                            {
                                if (!initallinkIDList.Contains(cesGroup[j].CES[k].jamE1[0][m].linkID))
                                {
                                    initallinkIDList.Add(cesGroup[j].CES[k].jamE1[0][m].linkID);
                                }
                            }
                        }
                    }

                    //Perform similarity search based on partition, grouping, and B-tree index
                    for (int j = 0; j < cesGroup.Count; j++)
                    {
                        for (int k = 0; k < cesGroup[j].CESid.Count; k++)
                        {
                            List<Group> group = new List<Group>();
                            TCES j1 = new TCES();
                            j1 = areajamEventList[i].areajam[cesGroup[j].CESid[k]];
                            group = getCESinGroup(j1, cesGroup);

                            for (int m = 0; m < group.Count; m++)
                            {
                                double target = j1.jamLength;
                                double distance = distance1;
                                List<int> indicesWithinThreshold = group[m].pTree.FindIndicesWithinThreshold(target, distance, group[m].CESlength.ToArray());

                                for (int n = 0; n < indicesWithinThreshold.Count; n++)
                                {
                                    if (group[m].CES[indicesWithinThreshold[n]].jamEventareaID != j1.jamEventareaID)
                                    {
                                        double d1 = Corrcoef(group[m].CES[indicesWithinThreshold[n]], j1);
                                        if (d1 > distance1)
                                        {
                                            cesGroup[j].CES[k].neighborsDic.Add(group[m].CES[indicesWithinThreshold[n]].jamEventareaID, d1);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    //Comparison2 -no Using index
                    //for (int m = 0; m < areajamEventList[i].areajam.Count; m++)
                    //{
                    //    for (int n = 0; n < areajamEventList[i].areajam.Count; n++)
                    //    {
                    //        double d1 = Mathfun.trafficEventCorrcoef5(areajamEventList[i].areajam[m], areajamEventList[i].areajam[n]);
                    //        if (areajamEventList[i].areajam[m].jamEventareaID != areajamEventList[i].areajam[n].jamEventareaID && d1 > 0.75)
                    //        {
                    //            areajamEventList[i].areajam[m].neighborsDic3.Add(areajamEventList[i].areajam[n].jamEventareaID, d1);
                    //        }
                    //    }
                    //}

                    //Perform efficient hierarchical clustering
                    List<Cluster> originalClusters = new List<Cluster>();
                    List<Cluster> finalClusters = new List<Cluster>();
                    originalClusters = initialCluster3(cesGroup);
                    cesGroup = getClusterAboutGroup(originalClusters, cesGroup);
                    finalClusters = startAnalysis3(originalClusters, distance1, cesGroup);
                    finalClusters = CalculatedAbnormality.Abnormality(finalClusters);
                    double sc = getSC(finalClusters);

                }
            }
        }

        // initial Cluster
        public static List<Cluster> initialCluster3(List<Group> j1)
        {

            List<Cluster> originalClusters = new List<Cluster>(); 
            int id = -1;
            for (int i = 0; i < j1.Count; i++)
            {
                for (int j = 0; j < j1[i].CES.Count; j++)
                {
                    id++;
                    Cluster tempCluster = new Cluster();
                    tempCluster.jamEvent.Add(j1[i].CES[j]);
                    tempCluster.clusterName = id;
                    tempCluster.during = j1[i].CES[j].during;
                    tempCluster.linkcount = j1[i].CES[j].linkcount;
                    tempCluster.linkID = j1[i].CES[j].alllinkID;
                    tempCluster.groupID = j1[i].CES[j].groupID;
                    originalClusters.Add(tempCluster);
                }               
            }
            return originalClusters;
        }


        //starting clustering Analysis
        public static List<Cluster> startAnalysis3(List<Cluster> originalClusters, double freq,List<Group> cesgroup)
        {
           
            List<Cluster> finalClusters = new List<Cluster>();
            finalClusters = originalClusters;

            int dfa1 = 0;
            bool flag = true;

            while (flag)
            {
                double min = 0;

                int mergeIndexA = 0;
                int mergeIndexB = 0;

                bool[,] boolArray = new bool[finalClusters.Count, finalClusters.Count];
                cesgroup = getClusterAboutGroup(finalClusters, cesgroup);

                for (int i = 0; i < finalClusters.Count ; i++)
                {
                    List<Cluster> clusterList = new List<Cluster>();
                    clusterList = dataProcessing.getGroupClusterID(finalClusters[i], cesgroup);
                    bool label = true;
                    List<string> s11 = new List<string>();
                    for (int j = 0; j < clusterList.Count; j++)
                    {
                        label = true;
                        if (finalClusters[i].clusterName != clusterList[j].clusterName && !boolArray[finalClusters[i].clusterName, clusterList[j].clusterName])
                        {
                            Cluster clusterA = finalClusters[i];
                            Cluster clusterB = clusterList[j];

                            double tempDis = 10000;
                            double tempDis1 = 0;

                            for (int m = 0; m < clusterA.jamEvent.Count; m++)
                            {
                                for (int n = 0; n < clusterB.jamEvent.Count; n++)
                                {
                                    bool isExist = clusterB.jamEvent[n].neighborsDic2.TryGetValue(clusterA.jamEvent[m].jamEventareaID, out tempDis1);
                                    if (isExist)
                                    {
                                        if (tempDis1 < tempDis)
                                        {
                                            tempDis = tempDis1;
                                        }
                                    }
                                    else
                                    {
                                        label = false;
                                        break;
                                    }                                      
                                }   
                                if(!label)
                                {
                                    break;
                                }
                            }
                            if (label)
                            {
                                if (tempDis > min)
                                {
                                    min = tempDis;
                                    mergeIndexA = finalClusters[i].clusterName;
                                    mergeIndexB = clusterList[j].clusterName;
                                }                      
                            }
                                                                      
                        }
                        boolArray[finalClusters[i].clusterName, clusterList[j].clusterName] = true;
                    }                   
                }
                if (min < freq)
                {
                    flag = false;
                }
                else
                {
                    finalClusters = mergeCluster(finalClusters, mergeIndexA, mergeIndexB);
              

                    dfa1++;
                    Console.WriteLine(dfa1);

                }
            }
            return finalClusters;
        }


        //merge Cluster
        public static List<Cluster> mergeCluster(List<Cluster> finalClusters, int mergeIndexA, int mergeIndexB)
        {
            if (mergeIndexA != mergeIndexB)
            {
                Cluster clusterA = finalClusters[mergeIndexA];
                Cluster clusterB = finalClusters[mergeIndexB];


                
                List<TCES> dpA = clusterA.jamEvent;
                List<TCES> dpB = clusterB.jamEvent;

                dpA.AddRange(dpB);
                finalClusters[mergeIndexA].jamEvent = dpA;
                finalClusters[mergeIndexA].linkID=getClusterLinkID(finalClusters[mergeIndexA]);
                finalClusters.Remove(finalClusters[mergeIndexB]);
            }
            for (int i = 0; i < finalClusters.Count; i++)
            {
                finalClusters[i].clusterName = i;
            }
            return finalClusters;
        }
       

       
        //Partition TCES into congestion areas
        public static void getAreajam()
        {
            for (int i = 0; i < finaljam.Count; i++)
            {
                if (areajamEventList.Count == 0)
                {
                    areajamSeq areajam = new areajamSeq();
                    areajam.areajam.Add(finaljam[i]);
                    areajam.areajam2.Add(i);
                    areajam.linkList = getLinkList(i, finaljam);
                    areajamEventList.Add(areajam);
                }
                else
                {
                    List<string> s1 = new List<string>();
                    s1 = getLinkList(i, finaljam);
                    bool label = false;
                    bool label2 = false;
                    int d1 = 0;
                    for (int j = 0; j < areajamEventList.Count; j++)
                    {
                        List<string> s2 = s1.Intersect(areajamEventList[j].linkList).ToList();
                        if (s2.Count >0)
                        {
                            List<string> s3 = s1.Except(areajamEventList[j].linkList).ToList();
                            areajamEventList[j].areajam.Add(finaljam[i]);
                            areajamEventList[j].areajam2.Add(i);
                            if (s3.Count() > 0)
                            {
                                areajamEventList[j].linkList.AddRange(s3);
                                label = true;
                                d1 = j;
                            }
                            label2 = true;
                            break;
                        }
                    }
                    if (label2 == false)
                    {
                        areajamSeq areajam = new areajamSeq();
                        areajam.areajam.Add(finaljam[i]);
                        areajam.areajam2.Add(i);
                        areajam.linkList.AddRange(s1);
                        areajamEventList.Add(areajam);
                    }
                    if (label == true)
                    {
                        label = false;
                        do
                        {
                            label = false;
                            List<string> s4 = new List<string>();

                            s4 = areajamEventList[d1].linkList;

                            for (int j = 0; j < areajamEventList.Count; j++)
                            {
                                if (j != d1)
                                {
                                    List<string> s2 = s4.Intersect(areajamEventList[j].linkList).ToList();
                                    if (s2.Count >0)
                                    {
                                        List<string> s3 = s4.Except(areajamEventList[j].linkList).ToList();
                                        areajamEventList[j].areajam.AddRange(areajamEventList[d1].areajam);
                                        areajamEventList[j].areajam2.AddRange(areajamEventList[d1].areajam2);

                                        if (s3.Count() > 0)
                                        {
                                            areajamEventList[j].linkList.AddRange(s3);
                                            areajamEventList.RemoveAt(d1);

                                            if (j > d1)
                                            {
                                                d1 = j - 1;
                                            }
                                            else
                                            {
                                                d1 = j;
                                            }
                                            label = true;
                                            continue;
                                        }
                                    }
                                }
                            }
                        }
                        while (label);
                    }
                }
            }        
        }


        //输入拥堵事件的编号，拥堵事件包含的路段ID集合
        public static HashSet<string> getLinkList3(int a, List<TCES> finaljam)
        {
            HashSet<string> s1 = new HashSet<string>();
            for (int i = 0; i < finaljam[a].jamE1.Count; i++)
            {
                for (int j = 0; j < finaljam[a].jamE1[i].Count; j++)
                {
                    if (!s1.Contains(finaljam[a].jamE1[i][j].linkID))
                    {
                        s1.Add(finaljam[a].jamE1[i][j].linkID);
                    }
                }
            }
            return s1;
        }

        //输入拥堵事件的编号，拥堵事件包含的路段ID集合
        public static List<string> getLinkList(int a, List<TCES> finaljam)
        {
            List<string> s1 = new List<string>();
            for (int i = 0; i < finaljam[a].jamE1.Count; i++)
            {
                for (int j = 0; j < finaljam[a].jamE1[i].Count; j++)
                {
                    if (!s1.Contains(finaljam[a].jamE1[i][j].linkID))
                    {
                        s1.Add(finaljam[a].jamE1[i][j].linkID);
                    }
                }
            }
            return s1;
        }

        public static List<string> getLinkList(TCES ad1)
        {
            List<string> s1 = new List<string>();
            for (int i = 0; i < ad1.jamE1.Count; i++)
            {
                for (int j = 0; j < ad1.jamE1[i].Count; j++)
                {
                    if (!s1.Contains(ad1.jamE1[i][j].linkID))
                    {
                        s1.Add(ad1.jamE1[i][j].linkID);
                    }
                }
            }
            return s1;
        }

        public static double getLinkcount(TCES ad1)
        {
            List<string> s1 = new List<string>();
            for (int i = 0; i < ad1.jamE1.Count; i++)
            {
                for (int j = 0; j < ad1.jamE1[i].Count; j++)
                {
                    if (!s1.Contains(ad1.jamE1[i][j].linkID))
                    {
                        s1.Add(ad1.jamE1[i][j].linkID);
                    }
                }
            }
            return s1.Count;
        }
      
     
   
        //获取与当前类簇距离最近的类簇
        public static Cluster getsimiarCluster(Cluster currCluster, List<Cluster> c1)
        {
            Cluster cc = new Cluster();
            double corr1 = 1000000;
            List<TCES> j1 = new List<TCES>();
            j1 = currCluster.jamEvent;
            for (int j = 0; j < c1.Count; j++)
            {
                double corr = 0;

                List<TCES> j2 = new List<TCES>();
                j2 = c1[j].jamEvent;
                for (int m = 0; m < j1.Count; m++)
                {
                    for (int n = 0; n < j2.Count; n++)
                    {
                        List<string> s1 = dataProcessing.getLinkList(j1[m]);
                        List<string> s2 = dataProcessing.getLinkList(j2[n]);
                        if (s1.Intersect(s2) != null)
                        {
                            corr += (1 - Corrcoef(j1[m], j2[n]));
                        }
                        else
                        {
                            corr += 1;
                        }
                    }
                }
                if (corr < corr1)
                {
                    cc = c1[j];
                }

            }
            return cc;
        }

        //获取与当前点距离最近的类簇
        public static Cluster getsimiarCluster(TCES jam1, List<Cluster> c1,int i)
        {
            Cluster cc = new Cluster();
            double corr1 = 1000000;
            List<TCES> j1 = new List<TCES>();
            for (int j = 0; j < c1.Count; j++)
            {
                if (i != j)
                {
                    double corr = 0;
                    List<TCES> j2 = new List<TCES>();
                    j2 = c1[j].jamEvent;

                    for (int n = 0; n < j2.Count; n++)
                    {
                        corr += (1 - Corrcoef(jam1, j2[n]));
                    }
                    double avcorr = corr / c1[j].jamEvent.Count;
                    if (avcorr < corr1)
                    {
                        cc = c1[j];
                        corr1 = avcorr;
                    }
                }
                
            }
            return cc;
        } 

        public static List<TCES> readJamEventTxt(string filepath)
        {
            finaljam = new List<TCES>();
            areajamEventList = new List<areajamSeq>();
            areajamEventList2 = new List<areajamSeq>();

            StreamReader sr1 = new StreamReader(File.Open(filepath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite), Encoding.GetEncoding("GB2312"));
            string line1 = sr1.ReadLine();
            int jamEventID = 0;
            while (true)
            {
                TCES j1 = new TCES();
                if (line1 == string.Empty || line1 == null) break;
                string[] ad = line1.Split('|');
                j1.endTime = Convert.ToInt16(ad[0]);
                string[] data = ad[1].Split(';');
                for (int i = 0; i < data.Length - 1; i++)
                {
                    List<Links> link1 = new List<Links>();
                    if (data[i] != string.Empty || data[i] != null)
                    {
                        string[] data2 = data[i].Split(',');

                        for (int j = 0; j < data2.Length - 1; j++)
                        {
                            Links link2 = new Links();
                            string[] data3 = data2[j].Split(' ');
                            link2.linkID = data3[0];
                            link2.trafficLevel = Convert.ToInt16(data3[1]);
                            double d1 = 0;
                            if (linkLengthDic.TryGetValue(link2.linkID, out d1))
                            {
                                link2.linklength = linkLengthDic[link2.linkID];
                            }
                            else
                            {
                                link2.linklength = 100;
                            }
                            j1.jamLength += link2.linklength;
                            j1.linkcount++;

                            link1.Add(link2);
                        }
                    }
                    j1.jamE1.Add(link1);
                }

                double maxlinkcount = 0;
                double maxLength = 0;
                for (int i = 0; i < j1.jamE1.Count; i++)
                {
                    double maxlinkcount1 = 0;
                    double maxLength1 = 0;
                    for (int j = 0; j < j1.jamE1[i].Count; j++)
                    {
                        maxlinkcount1++;
                        maxLength1 += j1.jamE1[i][j].linklength;
                    }
                    if (maxlinkcount1 > maxlinkcount)
                    {
                        maxlinkcount = maxlinkcount1;
                    }
                    if (maxLength1 > maxLength)
                    {
                        maxLength = maxLength1;
                    }
                }
                j1.maxlinkcount = maxlinkcount;
                j1.maxLength = maxLength;
                j1.avgLength = j1.jamLength / j1.jamE1.Count;

                if (j1.jamE1.Count > 0)
                {
                    j1.jamEventID = jamEventID;
                    j1.during = j1.jamE1.Count;
                    double linkcount = 0;
                    for (int i = 0; i < j1.jamE1.Count; i++)
                    {
                        linkcount += j1.jamE1[i].Count;
                    }
                    j1.linkcount = linkcount / j1.jamE1.Count;
                    j1.alllinkID = dataProcessing.getLinkList(j1);
                    finaljam.Add(j1);
                    jamEventID++;
                }
                line1 = sr1.ReadLine();
            }         
            return finaljam;
        }
  
        static Dictionary<string, double> linkLengthDic = new Dictionary<string, double>();
        public static Dictionary<string, double> readLinkLength(string filepath)
        {
             linkLengthDic = new Dictionary<string, double>();
            StreamReader sr1 = new StreamReader(File.Open(filepath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite), Encoding.GetEncoding("GB2312"));
            string line1 = sr1.ReadLine();
            while (true)
            {
                if (line1 == string.Empty || line1 == null) break;               
                string[] data = line1.Split('\t');
                linkLengthDic.Add(data[0], Convert.ToDouble(data[1]));
                line1 = sr1.ReadLine();

            }
            return linkLengthDic;
        }   

      
        public static List<string> getClusterLinkID(Cluster c1)
        {
            List<string> s1 = new List<string>();
           
            for (int i = 0; i < c1.jamEvent.Count; i++)
            {
                List<string> s2 = new List<string>();
                s2 = getLinkList(c1.jamEvent[i]);
                for (int j = 0; j < s2.Count; j++)
                {
                    if (!s1.Contains(s2[j]))
                    {
                        s1.Add(s2[j]);
                    }
                }                  
            }    
            return s1;
        }



        //compute silhouette coefficient
        public static double getSC(List<Cluster> c1)
        {
            List<double> allSC = new List<double>();
            if(c1.Count==1)
            {
                return 1;
            }
            
            for (int i = 0; i < c1.Count; i++)
            {
                for (int j = 0; j < c1[i].jamEvent.Count; j++)
                {
                    double a = 0;
                    double avDis = 0;
                    if (c1[i].jamEvent.Count > 1)
                    {
                        for (int k = 0; k < c1[i].jamEvent.Count; k++)
                        {
                            if (j != k)
                            {
                                avDis += (1 - Corrcoef(c1[i].jamEvent[j], c1[i].jamEvent[k]));
                            }
                        }
                        a = avDis / (c1[i].jamEvent.Count - 1);
                    }
                    else
                    {
                        a = 0;
                    }
                  
                    avDis = 0;
                    Cluster c2 = new Cluster();
                    c2 = getsimiarCluster(c1[i].jamEvent[j], c1, i);

                    for (int k = 0; k < c2.jamEvent.Count; k++)
                    {
                        avDis += (1 - Corrcoef(c1[i].jamEvent[j], c2.jamEvent[k]));                      
                    }
                    double b = avDis / c2.jamEvent.Count;
                    c1[i].jamEvent[j].sc = (b - a) / Math.Max(a, b);
                    allSC.Add((b - a) / Math.Max(a, b));
                }
            }
            return (allSC.Average());
        }


        //Obtain relevant groups based on the current  cluster, and then obtain the  clusters contained in these groups
        public static  List<Cluster> getGroupClusterID(Cluster c1, List<Group> cesGroupList)
        {
            List<Cluster> clusterList = new List<Cluster>();
            for (int i = 0; i < c1.linkID.Count; i++)
            {
                for (int j = 0; j < cesGroupList.Count; j++)
                {
                    if (c1.linkID[i] == cesGroupList[j].linkID)
                    {
                        clusterList.AddRange(cesGroupList[j].Cluster);
                    }
                }
            }
            clusterList=clusterList.Distinct().ToList();
            return clusterList;
        }

        //get groups related to the current TCES
        public static List<Group> getCESinGroup(TCES j1, List<Group> cesGroupList)
        {
            List<Group> group = new List<Group>(); 
            for (int i = 0; i < j1.alllinkID.Count ; i++)
            {
                for (int j = 0; j < cesGroupList.Count; j++)
                {
                    if (j1.alllinkID[i] == cesGroupList[j].linkID)
                    {
                        group.Add(cesGroupList[j]);
                        break;
                    }
                }
            }
            return group;
        }
        //Gets the group of associated clusters 
        public static List<Group> getClusterAboutGroup(List<Cluster> c1, List<Group> cesGroupList)
        {
            List<Group> group = new List<Group>();
            for (int i = 0; i < cesGroupList.Count; i++)
            {
                cesGroupList[i].Cluster = new List<Cluster>();

                for (int j = 0; j < c1.Count; j++)
                {
                    for (int k = 0; k < c1[j].linkID.Count; k++)
                    {
                        if (cesGroupList[i].linkID == c1[j].linkID[k])
                        {
                            cesGroupList[i].Cluster.Add(c1[j]);
                            break;
                        }
                    }
                }
            }
            return cesGroupList;
        }
        public static double Corrcoef(TCES c1, TCES c2)
        {
            double q2 = 1.75;
            double q3 = 3;
            double q4 = 4;

            int s12 = Math.Abs(c1.jamE1.Count - c2.jamE1.Count);

            List<int> a1 = new List<int>();
            List<int> a2 = new List<int>();

            if (c2.jamE1.Count > c1.jamE1.Count)
            {
                TCES g1 = new TCES();
                g1 = c1;
                c1 = c2;
                c2 = g1;
            }

            int b1 = 0;
            int b2 = 0;

            b1 = c1.jamE1.Count;
            b2 = c2.jamE1.Count;
            List<double> corrlist1 = new List<double>();
            List<double> corrlist2 = new List<double>();

            for (int i = 0; i < b2; i++)
            {
                List<Links> d1 = new List<Links>();
                List<Links> d2 = new List<Links>();
                d1 = c1.jamE1[i];
                d2 = c2.jamE1[i];
                List<Links> ss1 = new List<Links>();
                List<Links> ss2 = new List<Links>();

                for (int j = 0; j < d1.Count; j++)
                {
                    for (int k = 0; k < d2.Count; k++)
                    {
                        if (d1[j].linkID == d2[k].linkID)
                        {
                            Links l1 = new Links();
                            Links l2 = new Links();
                            l1.linkID = d1[j].linkID;
                            l1.trafficLevel = d1[j].trafficLevel;
                            l1.linklength = d1[j].linklength;
                            l2.linkID = d2[k].linkID;
                            l2.trafficLevel = d2[k].trafficLevel;
                            l2.linklength = d2[k].linklength;
                            ss1.Add(l1);
                            ss2.Add(l2);
                        }
                    }
                }

                double sim1 = 0;
                for (int j = 0; j < ss1.Count; j++)
                {
                    if (ss1[j].trafficLevel == 3)
                    {
                        sim1 += (q2 * ss1[j].linklength);
                    }
                    else if (ss1[j].trafficLevel == 4)
                    {
                        sim1 += (q3 * ss1[j].linklength);
                    }
                    else
                    {
                        sim1 += (q4 * ss1[j].linklength);
                    }
                }
                double sim2 = 0;
                for (int j = 0; j < ss2.Count; j++)
                {
                    if (ss2[j].trafficLevel == 3)
                    {
                        sim2 += (q2 * ss2[j].linklength);
                    }
                    else if (ss2[j].trafficLevel == 4)
                    {
                        sim2 += (q3 * ss2[j].linklength);
                    }
                    else
                    {
                        sim2 += (q4 * ss2[j].linklength);
                    }
                }

                double sim3 = 0;
                for (int j = 0; j < d1.Count; j++)
                {
                    if (d1[j].trafficLevel == 3)
                    {
                        sim3 += (q2 * d1[j].linklength);
                    }
                    else if (d1[j].trafficLevel == 4)
                    {
                        sim3 += (q3 * d1[j].linklength);
                    }
                    else
                    {
                        sim3 += (q4 * d1[j].linklength);
                    }
                }
                double sim4 = 0;
                for (int j = 0; j < d2.Count; j++)
                {
                    if (d2[j].trafficLevel == 3)
                    {
                        sim4 += (q2 * d2[j].linklength);
                    }
                    else if (d2[j].trafficLevel == 4)
                    {
                        sim4 += (q3 * d2[j].linklength);
                    }
                    else
                    {
                        sim4 += (q4 * d2[j].linklength);
                    }
                }
                corrlist1.Add(sim1 / sim3);
                corrlist2.Add(sim2 / sim4);

            }

            for (int i = b2; i < b1; i++)
            {
                corrlist1.Add(0);
            }



            List<double> totallinklength1 = new List<double>();
            List<double> totallinklength2 = new List<double>();

            double fd1 = 0;
            double fd2 = 0;
            for (int i = 0; i < c1.jamE1.Count; i++)
            {
                double l1 = 0;
                for (int j = 0; j < c1.jamE1[i].Count; j++)
                {
                    l1 += c1.jamE1[i][j].linklength;
                    fd1 += c1.jamE1[i][j].linklength;
                }
                totallinklength1.Add(l1);
            }
            for (int i = 0; i < c2.jamE1.Count; i++)
            {
                double l1 = 0;
                for (int j = 0; j < c2.jamE1[i].Count; j++)
                {
                    l1 += c2.jamE1[i][j].linklength;
                    fd2 += c2.jamE1[i][j].linklength;
                }
                totallinklength2.Add(l1);
            }

            double h1 = 0;
            for (int i = 0; i < corrlist1.Count; i++)
            {
                h1 += (corrlist1[i] * (totallinklength1[i] / fd1));
            }
            double h2 = 0;
            for (int i = 0; i < corrlist2.Count; i++)
            {
                h2 += (corrlist2[i] * (totallinklength2[i] / fd2));
            }
            return (h1 + h2) / 2;

        }
    
    }
}
