﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public class CalculatedAbnormality
    {


        public static List<Cluster> Abnormality(List<Cluster> finalClusters)
        {
            for(int i=0;i<finalClusters.Count;i++)
            {
                finalClusters[i].jamcount=finalClusters[i].jamEvent.Count;
            }
            var sortedClusters = finalClusters.OrderByDescending(cluster => cluster.jamEvent.Count).ToList();
            List<Cluster> finalClusters1 = new List<Cluster>();
            foreach (Cluster cluster in sortedClusters)
            {
                finalClusters1.Add(cluster);
            }
            double[] data = new double[finalClusters1.Count];
            for (int i = 0; i < finalClusters1.Count; i++)
            {
                if (i == 0)
                {
                    finalClusters1[i].ROCF = 0;
                    finalClusters1[i].abnormbolvalue = 0;
                    data[i] = 0;
                }
                else
                {
                    finalClusters1[i].ROCF = 1 - Math.Exp(-finalClusters1[i].jamEvent.Count / finalClusters1[i - 1].jamEvent.Count);
                    finalClusters1[i].abnormbolvalue = finalClusters1[i].ROCF * finalClusters1[i].linkcount * finalClusters1[i].during;
                    data[i] = finalClusters1[i].abnormbolvalue;
                }
            }
            double d1 = DetectOutliers(data);
            for (int i = 0; i < finalClusters1.Count; i++)
            {
                if (finalClusters1[i].abnormbolvalue > d1)
                {
                    finalClusters1[i].isnormalCluster = false;
                }
                else
                {
                    finalClusters1[i].isnormalCluster = true;
                }
            }
            return finalClusters1;
        }

        public static double DetectOutliers(double[] data)
        {           
            double q1 = GetQuartile(data, 0.25);
            double q3 = GetQuartile(data, 0.75);
            double iqr = q3 - q1;
            double upperBound = q3 + 3* iqr;
            double lowerBound = q1 - 3 * iqr;
            return upperBound;
        }

        public static double GetQuartile(double[] data, double quartile)
        {
            Array.Sort(data);
            int n = data.Length;
            double pos = (quartile ) * (n - 1);
            int lowerIndex = (int)Math.Floor(pos);
            int upperIndex = (int)Math.Ceiling(pos);
            double lowerValue = data[lowerIndex];
            double upperValue = data[upperIndex];
            return lowerValue + (pos - lowerIndex) * (upperValue - lowerValue);
        }

    }
}
