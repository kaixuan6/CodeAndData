﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WindowsFormsApplication1
{
    class Group
    {
        public string linkID;
        public List<string> initallinkIDList = new List<string>();
        public List<int> CESid = new List<int>();
        public List<double> CESlength = new List<double>();
        public List<TCES> CES = new List<TCES>();
        public List<Cluster> Cluster = new List<Cluster>();
        public balance_Tree.balanceTree pTree = new balance_Tree.balanceTree();
    }
}
