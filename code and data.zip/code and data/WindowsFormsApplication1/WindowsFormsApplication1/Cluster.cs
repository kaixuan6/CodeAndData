﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public class Cluster
    {
        public int clusterName;
        public List<TCES> jamEvent = new List<TCES>();
        public TCES clusterCenter = new TCES();
        public double abnormbolvalue;
        public double ROCF;
        public bool isnormalCluster;
        public bool isRead;
        public double during;
        public double linkcount;
        public double jamcount;
        public double avgLength;

        public List<string> linkID = new List<string>();
        public int groupID;
        public bool isExist=true;

    }
}
