﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics;
using MathNet.Numerics.LinearAlgebra.Double;
using System.Collections;
using System.IO;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Threading;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
   
        private void button6_Click(object sender, System.EventArgs e)
        {
            dataProcessing.readLinkLength(@"filepath");
            string path = @"/path";
            foreach (string file in Directory.EnumerateFiles(path))
            {
                dataProcessing.readJamEventTxt(file);
                dataProcessing.getAreajam();
                dataProcessing.areaEventCluster3(0.7, file);          
            }        
        }

      

   
    }
}
