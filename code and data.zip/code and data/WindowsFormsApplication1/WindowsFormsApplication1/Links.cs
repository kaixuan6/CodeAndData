﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public class Links
    {
        public string linkID;     
        public int timeID;
        public string[,] dayt;   
        public int[,] montht;  
        public double linkX;
        public double linkY;
        public double linklength;
        public int trafficLevel;
        public string longTraffic;
        public List<Links> adjLink = new List<Links>();
        public bool isVisit;
        public Dictionary<string, double> rankings = new Dictionary<string, double>(); 
    }
}
