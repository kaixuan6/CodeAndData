﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public class TCES
    {
        public int jamEventID;
        public int jamEventareaID;
        public int groupID;
        public string status = "";
        public List<List<Links>> jamE1 = new List<List<Links>>(); 
        public List<TCES> neighbors = new List<TCES>();
        public Dictionary<int, double> neighborsDic = new Dictionary<int, double>();
        public Dictionary<int, double> neighborsDic2 = new Dictionary<int, double>();
        public Dictionary<int, double> neighborsDic3 = new Dictionary<int, double>();

        public int startTime;
        public int endTime;
        public double during;
        public double linkcount;
        public double maxlinkcount;

        public double jamLength;
        public double maxLength;
        public double avgLength;


        public List<Links> maxSpace = new List<Links>();
        public List<string> maxSpace2 = new List<string>();
        public double lofValue;
        public double a_i;
        public double b_i;
        public double s_i;
        public double lof;
        public double sc;
        public List<string> alllinkID = new List<string>();


    }
}
