﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace balance_Tree
{
    public class TreeNode
    {
        public double Value { get; set; }
        public int Index { get; set; }
        public TreeNode Left { get; set; }
        public TreeNode Right { get; set; }

        public TreeNode(double value, int index)
        {
            this.Value = value;
            this.Index = index;
            this.Left = null;
            this.Right = null;
        }
    }
}
