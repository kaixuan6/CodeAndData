﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace balance_Tree
{
    public class balanceTree
    {
        public TreeNode Root { get; set; }
        private Dictionary<double, int> _indexMap = new Dictionary<double, int>();

        public balanceTree()
        {
            Root = null;
        }

        public void Insert(double[] values, int index)
        {
            if (Root == null)
            {
                Root = new TreeNode(values[index], index);
                _indexMap.Add(values[index], index);
            }
            else
            {
                InsertNode(Root, values, index);
            }
        }

        private void InsertNode(TreeNode node, double[] values, int index)
        {
            if (_indexMap.ContainsKey(values[index]))
            {
                values[index] = values[index] - 0.0000001;
            }

            if (values[index] < node.Value)
            {
                if (node.Left == null)
                {
                    node.Left = new TreeNode(values[index], index);
                    _indexMap.Add(values[index], index);
                }
                else
                {
                    InsertNode(node.Left, values, index);
                }
            }
            else
            {
                if (node.Right == null)
                {
                    node.Right = new TreeNode(values[index], index);
                    _indexMap.Add(values[index], index);
                }
                else
                {
                    InsertNode(node.Right, values, index);
                }
            }
        }

        public List<int> FindIndicesWithinThreshold(double targetValue, double threshold, double[] originalValues)
        {
            var result = new List<int>();
            FindIndicesWithinThreshold(Root, targetValue, threshold, result, originalValues);
            return result;
        }

        private void FindIndicesWithinThreshold(TreeNode node, double targetValue, double threshold, List<int> result, double[] originalValues)
        {
            if (node == null) return;

            double minVal = Math.Min(node.Value, targetValue);
            double maxVal = Math.Max(node.Value, targetValue);
            double distance = (1 + minVal / maxVal) / 2;

            if (distance >= threshold && distance <= 1)
            {
                result.Add(node.Index);
            }

            if (distance >= threshold)
            {
                FindIndicesWithinThreshold(node.Left, targetValue, threshold, result, originalValues);
                FindIndicesWithinThreshold(node.Right, targetValue, threshold, result, originalValues);
            }
            else if (distance < threshold && targetValue > node.Value)
            {
                FindIndicesWithinThreshold(node.Right, targetValue, threshold, result, originalValues);
            }
            else if (distance < threshold && targetValue <= node.Value)
            {
                FindIndicesWithinThreshold(node.Left, targetValue, threshold, result, originalValues);
            }
        }
    }
}
